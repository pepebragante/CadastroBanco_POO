package func;

public class Utils {
    // Função de validação simples de CPF
    public static boolean validarCpf(String cpf) {
        return cpf != null && cpf.matches("\\d{11}");
    }
}